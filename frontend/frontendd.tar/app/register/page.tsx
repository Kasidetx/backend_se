// app/register/page.tsx
"use client";

import { useState } from "react";
import api from "@/lib/api";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function RegisterPage() {
    const router = useRouter();
    const [formData, setFormData] = useState({
        username: "",
        password: "",
        firstName: "",
        lastName: "",
        studentId: "",
        role: "STUDENT", // Default role [cite: 72]
    });
    const [error, setError] = useState("");

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            await api.post("/auth/register", formData);
            alert("สมัครสมาชิกสำเร็จ! กรุณาเข้าสู่ระบบ");
            router.push("/login");
        } catch (err: any) {
            setError(err.response?.data?.message || "การสมัครสมาชิกผิดพลาด");
        }
    };

    return (
        <div className="flex min-h-screen items-center justify-center bg-gray-100 py-10">
            <div className="w-full max-w-lg bg-white p-8 rounded-lg shadow-md">
                <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">สมัครสมาชิก</h2>

                {error && <div className="mb-4 p-2 bg-red-100 text-red-600 text-sm rounded">{error}</div>}

                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-gray-700 text-sm">ชื่อจริง</label>
                            <input name="firstName" onChange={handleChange} className="w-full px-3 py-2 border rounded text-black" required />
                        </div>
                        <div>
                            <label className="block text-gray-700 text-sm">นามสกุล</label>
                            <input name="lastName" onChange={handleChange} className="w-full px-3 py-2 border rounded text-black" required />
                        </div>
                    </div>

                    <div>
                        <label className="block text-gray-700 text-sm">รหัสนักศึกษา (ถ้ามี)</label>
                        <input name="studentId" onChange={handleChange} className="w-full px-3 py-2 border rounded text-black" />
                    </div>

                    <div>
                        <label className="block text-gray-700 text-sm">บทบาท</label>
                        <select name="role" onChange={handleChange} className="w-full px-3 py-2 border rounded text-black">
                            <option value="STUDENT">นักศึกษา (Student)</option>
                            <option value="CLUB_ADMIN">ผู้จัดกิจกรรม (Club Admin)</option>
                            <option value="DEAN">คณะบดี (Dean)</option>
                        </select>
                    </div>

                    <div>
                        <label className="block text-gray-700 text-sm">Username</label>
                        <input name="username" onChange={handleChange} className="w-full px-3 py-2 border rounded text-black" required />
                    </div>
                    <div>
                        <label className="block text-gray-700 text-sm">Password</label>
                        <input type="password" name="password" onChange={handleChange} className="w-full px-3 py-2 border rounded text-black" required />
                    </div>

                    <button type="submit" className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition">
                        สมัครสมาชิก
                    </button>
                </form>
                <p className="mt-4 text-center text-sm text-gray-600">
                    มีบัญชีแล้ว? <Link href="/login" className="text-blue-500 hover:underline">เข้าสู่ระบบ</Link>
                </p>
            </div>
        </div>
    );
}