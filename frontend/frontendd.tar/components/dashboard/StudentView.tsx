// components/dashboard/StudentView.tsx
"use client";

import { useEffect, useState } from "react";
import api from "@/lib/api";
import Link from "next/link";
import { PDFDownloadLink } from "@react-pdf/renderer";
import ReportPDF from "../ReportPDF";

export default function StudentView() {
    const [jobs, setJobs] = useState<any[]>([]);
    const [reportData, setReportData] = useState<any>(null);
    const [loading, setLoading] = useState(true);

    // ดึงข้อมูลกิจกรรม
    useEffect(() => {
        const fetchData = async () => {
            try {
                // ดึงรายการกิจกรรมทั้งหมด
                const resJobs = await api.get("/jobs");
                setJobs(resJobs.data);

                // ดึงข้อมูลรายงาน PDF ของตัวเอง
                const resReport = await api.get("/jobs/my-report/export");
                setReportData(resReport.data);
            } catch (error) {
                console.error("Error:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    const handleRegister = async (jobId: number) => {
        if (!confirm("ยืนยันการลงทะเบียน?")) return;
        try {
            await api.post(`/jobs/${jobId}/register`);
            alert("ลงทะเบียนสำเร็จ!");
            // อาจจะ refresh jobs หรือ update state ตรงนี้
        } catch (err: any) {
            alert(err.response?.data?.error || "ลงทะเบียนไม่สำเร็จ");
        }
    };

    if (loading) return <p>กำลังโหลดข้อมูลกิจกรรม...</p>;

    return (
        <div>
            {/* กล่องแสดงสถานะชั่วโมง (Hero Stats) */}
            <div className="bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-700 p-8 rounded-2xl shadow-xl mb-8 flex flex-col md:flex-row justify-between items-center text-white transform transition-all hover:scale-[1.01]">
                <div>
                    <h3 className="text-blue-100 font-medium mb-1">ชั่วโมงจิตอาสาที่สะสมได้ทั้งหมด</h3>
                    <p className="text-5xl font-bold">
                        {reportData?.totalHours || "0.00"} <span className="text-xl font-normal opacity-80">ชั่วโมง</span>
                    </p>
                </div>

                <div className="mt-6 md:mt-0">
                    {reportData && reportData.activities.length > 0 ? (
                        <PDFDownloadLink
                            document={<ReportPDF data={reportData} />}
                            fileName={`Volunteer_Report_${reportData.student.student_id}.pdf`}
                            className="bg-white/20 hover:bg-white/30 backdrop-blur-sm border border-white/30 text-white px-6 py-3 rounded-full font-medium transition-all flex items-center gap-2 shadow-lg"
                        >
                            {({ loading }) => (loading ? "⏳ กำลังเตรียมเอกสาร..." : "📥 ดาวน์โหลดรายงาน PDF")}
                        </PDFDownloadLink>
                    ) : (
                        <span className="text-blue-200 text-sm bg-black/10 px-4 py-2 rounded-full">
                            ยังไม่มีชั่วโมงที่ได้รับการอนุมัติ
                        </span>
                    )}
                </div>
            </div>
            <div className="mb-6 bg-blue-50 p-4 rounded-lg border border-blue-100 flex justify-between items-center">
                <div>
                    <h3 className="text-lg font-bold text-blue-800">เข้าร่วมกิจกรรมอยู่ใช่ไหม?</h3>
                    <p className="text-sm text-blue-600">สแกน QR Code เพื่อ Check-in หรือ Check-out ได้ที่นี่</p>
                </div>
                <Link
                    href="/scan"
                    className="bg-blue-600 text-white px-6 py-3 rounded-lg font-bold shadow-lg hover:bg-blue-700 transform hover:scale-105 transition"
                >
                    📷 สแกน QR
                </Link>
            </div>
            <h2 className="text-2xl font-bold mb-4 text-black">กิจกรรมที่เปิดรับสมัคร</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {jobs.map((job) => (
                    <div key={job.id} className="bg-white border border-gray-100 p-6 rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 flex flex-col">
                        
                        <div className="flex-1">
                            <div className="flex justify-between items-start mb-4">
                                <h3 className="text-xl font-bold text-gray-800 line-clamp-2">{job.title}</h3>
                                <span className="bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap">
                                    {job.hours_credit} ชม.
                                </span>
                            </div>
                            <p className="text-gray-500 text-sm mb-4 line-clamp-3 leading-relaxed">{job.description}</p>
                            
                            <div className="space-y-2 text-sm text-gray-600 bg-gray-50 p-4 rounded-xl">
                                <p className="flex items-center gap-2">📍 {job.location}</p>
                                <p className="flex items-center gap-2">⏰ {new Date(job.start_time).toLocaleString("th-TH")}</p>
                            </div>
                        </div>

                        <div className="mt-6 pt-4 border-t border-gray-100 flex items-center justify-between">
                            <div className="text-sm">
                                <span className="text-gray-500">ลงทะเบียนแล้ว</span>
                                <p className="font-bold text-blue-600">{job.current_attendees} <span className="text-gray-400 font-normal">/ {job.max_capacity}</span></p>
                            </div>
                            
                            {job.status === 'OPEN' && job.current_attendees < job.max_capacity ? (
                                <button
                                    onClick={() => handleRegister(job.id)}
                                    className="bg-blue-600 text-white px-6 py-2 rounded-full hover:bg-blue-700 hover:shadow-lg transition-all font-medium"
                                >
                                    ลงทะเบียน
                                </button>
                            ) : (
                                <button disabled className="bg-gray-100 text-gray-400 px-6 py-2 rounded-full cursor-not-allowed font-medium">
                                    {job.status === 'OPEN' ? 'เต็มแล้ว' : 'ปิดรับสมัคร'}
                                </button>
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}